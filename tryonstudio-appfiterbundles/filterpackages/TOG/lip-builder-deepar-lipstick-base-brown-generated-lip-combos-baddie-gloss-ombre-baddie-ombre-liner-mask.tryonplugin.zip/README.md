# Lip Builder - Deepar Lipstick Base Brown / Generated Lip Combos Baddie Gloss Ombre Baddie Ombre Liner Mask

This package is ready to import into an app that has the TryOn Studio runtime.

It is not a DeepAR .deepar effect. Do not load it with DeepAR switchEffect or switchEffectWithSlot.

## Files

- manifest.json: app import manifest
- filters/lip-builder-deepar-lipstick-base-brown-generated-lip-combos-baddie-gloss-ombre-baddie-ombre-liner-mask.tryonfilter: the saved TryOn Studio look
- textures/: extracted texture copies for inspection or native pipelines
- integration/: runtime contract and Flutter asset snippet

## App Load Rule

1. Read manifest.json.
2. Load filters/lip-builder-deepar-lipstick-base-brown-generated-lip-combos-baddie-gloss-ombre-baddie-ombre-liner-mask.tryonfilter.
3. Verify schema is tryonstudio.filter.v1 and format is tryonfilter-json.
4. Decode filter.assets[].dataUrl or use the matching files under textures/.
5. Render with a 468-point face mesh tracker and the saved mesh triangles/UVs.
6. Respect filter.mobileRenderer.lipPreviewMode. If it is "macbook", run the saved MacBook lip camera pass and use the runtime-lip-grain asset before lip colour, shimmer, liner and gloss.
7. Draw gloss last with the centred gloss UV remap. If filter.lipControls.shimmer is above zero, draw shimmer as a separate mesh-screen layer using lipControls.shimmerColor and either the lipshimmer asset or runtime-lip-shimmer.
8. Draw eye makeup from filter.eyeControls using the same face landmarks as the Studio preview: clipped eyeshadow base, transition/depth zones, liner shape, lash style, and optional iris colour.

The app must use a TryOn Studio renderer over the native camera frame. If the receiving app uses DeepAR for other effects, keep this path separate from DeepAR.
